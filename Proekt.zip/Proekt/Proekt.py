import pygame
import sys

def check(mas,sign): #проверка игры
      zer = 0
      for row in mas:
            zer = zer + row.count(0)
            if row.count(sign)==3:
                  return 'Победил ' + sign
      for col in range(3):
            if mas[0][col]==sign and mas[1][col]==sign and mas[2][col]==sign:
                  return 'Победил ' + sign
      if mas[0][0]==sign and mas[1][1]==sign and mas[2][2]==sign:
            return 'Победил ' + sign
      if mas[0][2]==sign and mas[1][1]==sign and mas[2][0]==sign:
            return 'Победил ' + sign
      if zer == 0:
            return 'Ничья'
      return False

pygame.init()
size_block = 200 #размер клеток для XO
margin = 30 #пространство между клетками
width = height = size_block*3 + margin*4 

size_window = (width,height)
screen = pygame.display.set_mode(size_window)
pygame.display.set_caption('XOX')


black = (0,0,0)
red = (255,0,0)
green = (0,255,0)
white = (255,255,255)
mas = [[0]*3 for i in range(3)] #создание массива из 3-х списков
query = 0 #очередь игрока, делающего ход
game_over = False #флажок для статуса игры (идёт или закончен)

print('Чтобы играть в XOX, вы должны навести мышкой на свободное поле и нажать ЛКМ\n' +
      'Игра начинается всегда с X. В иконке окна показывается чей ход\n' + '='*50 + '\nРаботающие клавишы:\n' + 'Пометить клетку - ЛКМ\n' +
      'Перезапуск игры - SPACEBAR\n' + 'Выход из игры - ESCAPE\n' + 'Также здесь присутствует пасхалка :)')

while True:
      for event in pygame.event.get():
            if event.type == pygame.QUIT:
                  pygame.quit()
                  sys.exit(0)
            elif event.type == pygame.MOUSEBUTTONDOWN and not game_over: #ход игрока
                  x_mouse, y_mouse = pygame.mouse.get_pos()
                  col = x_mouse // (size_block + margin)
                  row = y_mouse // (size_block + margin)
                  if x_mouse < width - margin and y_mouse < height - margin and mas[row][col] == 0: #проверка позиций курсора нужен для исключения ошибки о выходе за границы
                        if query % 2 == 0:
                              mas[row][col] = 'X'
                        else:
                              mas[row][col] = 'O'
                        query = query + 1
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE: #перезапуск игры (в любой момент можно)
                  game_over = False
                  mas = [[0]*3 for i in range(3)]
                  query = 0
                  screen.fill(black)
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                  pygame.quit()
                  sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_DELETE:
                  print('\nПоздравляем с нахождением пасхалки в игре XOX!\n' +
                        'Игру создали студенты ЮФУ факультета ИММиКН 1.1 2021-2022:\n' +
                        'Тинчурин Руслан, Шароватова Валерия, Очиров Эдуард, Косыгин Андрей\n')
      if not game_over:       
            for row in range(3):
                  for col in range(3):
                        if mas[row][col] == 'X':
                              color = red
                        elif mas[row][col] =='O':
                              color = green
                        else:
                              color = white
                        x = col*size_block + (col+1)*margin
                        y = row*size_block + (row+1)*margin
                        pygame.draw.rect(screen, color, (x,y,size_block,size_block))
                        if color == red:
                              pygame.draw.line(screen,white,(x+5,y+5),(x+size_block-5,y+size_block-5),3)
                              pygame.draw.line(screen,white,(x+size_block-5,y+5),(x+5,y+size_block-5),3)
                        elif color == green:
                              pygame.draw.circle(screen, white, (x+size_block//2,y+size_block//2),size_block//2-3,3)
      if (query-1)%2 == 0:
            game_over = check(mas,'X')
            icon = pygame.image.load('O.png')
            pygame.display.set_icon(icon)
      else:
            game_over = check(mas,'O')
            icon = pygame.image.load('X.png')
            pygame.display.set_icon(icon)

      if game_over:
            screen.fill(black)
            font = pygame.font.SysFont('arial',40)
            text1 = font.render(game_over, True, white)
            text_rect = text1.get_rect()
            text_x = screen.get_width() / 2 - text_rect.width / 2
            text_y = screen.get_height() / 2 - text_rect.height / 2
            screen.blit(text1,(text_x,text_y))
            text1 = font.render('Для повтора нажмите SPACE', True, white)
            text_rect = text1.get_rect()
            text_x = screen.get_width() / 2 - text_rect.width / 2
            text_y = screen.get_height() / 3 - text_rect.height / 2
            screen.blit(text1,(text_x,text_y))

      pygame.display.update()
