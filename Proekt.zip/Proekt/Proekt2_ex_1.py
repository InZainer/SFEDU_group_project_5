'''
«Разделение списка на подсписки». На вход подается строка чисел, из которой 
формируется список. Напишите программу, создающую вложенный список, 
элементами которого являются все возможные подсписки исходного списка, 
включая пустой. Пример ввода: a b c Пример вывода: [[], ['a'], ['b'], ['c'],
['a', 'b'], ['a', 'c'], ['b', 'c'], ['a', 'b', 'c']]

'''

import itertools

s = 'a b c'

def comb(s):
    '''
    Разделение списка на подсписки.
    Вх. данные: s(str)
    Вых. данные: a(list)
    '''
    s = s.replace(' ', '')
    a = [[]]
    for i in s:
        s1 = list(i)
        a.append(s1)
        
    for n in range(2, len(s)):
        com_set = itertools.combinations(s, n)
        for i in com_set:
            a.append(list(i))
        
    a.append(list(s))

    
    if (len(s) == 0 or len(s) == 1):
        a.pop(-1)
        
    return a   
print(s)       
print(comb(s))
